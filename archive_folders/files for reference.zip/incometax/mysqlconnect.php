<?php 
$lnk=mysqli_connect("localhost","shivangi","honey","shivangi");
//$lnk=mysqli_connect("localhost","aniket","aniket","aniket");
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
 }
?>
